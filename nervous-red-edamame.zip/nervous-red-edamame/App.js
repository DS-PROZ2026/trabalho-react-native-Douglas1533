import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  Image
} from 'react-native';

const QUIZ = [
  {
    id: 1,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/1/1e/FIFA_World_Cup_Trophy.jpg',
    pergunta: 'Qual país ganhou a Copa do Mundo de 2022?',
    opcoes: ['Brasil', 'França', 'Argentina', 'Alemanha'],
    respostaCerta: 2
  },
  {
    id: 2,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/5/53/Lionel_Messi_20180626.jpg',
    pergunta: 'Quem é conhecido como "La Pulga"?',
    opcoes: ['Cristiano Ronaldo', 'Neymar', 'Messi', 'Mbappé'],
    respostaCerta: 2
  },
  {
    id: 3,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/8/8c/Cristiano_Ronaldo_2018.jpg',
    pergunta: 'Qual jogador usa a camisa 7 famosa no Real Madrid e Manchester United?',
    opcoes: ['Messi', 'Cristiano Ronaldo', 'Neymar', 'Suárez'],
    respostaCerta: 1
  },
  {
    id: 4,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/6/6e/Pel%C3%A9_1960.jpg',
    pergunta: 'Quem é considerado o Rei do Futebol?',
    opcoes: ['Maradona', 'Pelé', 'Romário', 'Zidane'],
    respostaCerta: 1
  },
  {
    id: 5,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/0/0f/Maracan%C3%A3_Stadium.jpg',
    pergunta: 'Qual estádio é conhecido como Maracanã?',
    opcoes: ['São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Salvador'],
    respostaCerta: 1
  },
  {
    id: 6,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/5/56/Football_field.svg',
    pergunta: 'Quantos jogadores cada time tem em campo?',
    opcoes: ['9', '10', '11', '12'],
    respostaCerta: 2
  },
  {
    id: 7,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/7/7a/Yellow_card.svg',
    pergunta: 'O que significa um cartão amarelo?',
    opcoes: ['Gol anulado', 'Advertência', 'Expulsão', 'Pênalti'],
    respostaCerta: 1
  },
  {
    id: 8,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/4/4f/Red_card.svg',
    pergunta: 'O cartão vermelho significa:',
    opcoes: ['Gol', 'Substituição', 'Expulsão', 'Pausa'],
    respostaCerta: 2
  },
  {
    id: 9,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/6/6e/Football_iu_1996.jpg',
    pergunta: 'Qual país inventou o futebol moderno?',
    opcoes: ['Brasil', 'Inglaterra', 'Espanha', 'Itália'],
    respostaCerta: 1
  },
  {
    id: 10,
    imagem: 'https://upload.wikimedia.org/wikipedia/commons/9/9e/Soccer_ball.svg',
    pergunta: 'Quantos minutos tem uma partida oficial (sem prorrogação)?',
    opcoes: ['60', '80', '90', '120'],
    respostaCerta: 2
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);
  const [bloqueado, setBloqueado] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indice) {
    setOpcaoSelecionada(indice);
    setBloqueado(true);

    setTimeout(() => {
      setCarregando(true);

      setTimeout(() => {
        const pergunta = QUIZ[perguntaAtual];

        if (indice === pergunta.respostaCerta) {
          setPontuacao((p) => p + 1);
        }

        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual((p) => p + 1);
        } else {
          setTelaAtual('resultado');
        }

        setOpcaoSelecionada(null);
        setBloqueado(false);
        setCarregando(false);
      }, 1500);
    }, 1000);
  }

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.tituloPrincipal}>Quiz de Futebol ⚽</Text>

        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo}>
          <Text style={styles.textoBotaoIniciar}>INICIAR</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.titulo}>Fim de Jogo!</Text>
        <Text style={styles.subtitulo}>
          Você fez {pontuacao} de {QUIZ.length}
        </Text>

        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio}>
          <Text style={styles.textoBotaoAcao}>Voltar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text>Validando resposta...</Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];

  return (
    <View style={styles.tela}>

      <Text style={styles.progresso}>
        Pergunta {perguntaAtual + 1} / {QUIZ.length}
      </Text>

      <View style={styles.cartaoPergunta}>

        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagem}
        />

        <Text style={styles.textoPergunta}>
          {pergunta.pergunta}
        </Text>

      </View>

      {pergunta.opcoes.map((opcao, index) => (
        <TouchableOpacity
          key={index}
          disabled={bloqueado}
          onPress={() => responder(index)}
          style={[
            styles.botaoOpcao,

            opcaoSelecionada === index &&
              index === pergunta.respostaCerta && {
                backgroundColor: '#22c55e',
                borderColor: '#22c55e'
              },

            opcaoSelecionada === index &&
              index !== pergunta.respostaCerta && {
                backgroundColor: '#ef4444',
                borderColor: '#ef4444'
              }
          ]}
        >
          <Text style={styles.textoOpcao}>{opcao}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, padding: 20, paddingTop: 60, backgroundColor: '#f8fafc' },
  telaCentrada: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  tituloPrincipal: { fontSize: 30, fontWeight: '900' },
  titulo: { fontSize: 28, fontWeight: '900' },
  subtitulo: { fontSize: 16, marginTop: 10 },

  botaoIniciar: { backgroundColor: '#10b981', padding: 20, borderRadius: 15, marginTop: 30 },
  textoBotaoIniciar: { color: 'white', fontWeight: '800' },

  botaoAcao: { backgroundColor: '#3b82f6', padding: 15, marginTop: 20, borderRadius: 10 },
  textoBotaoAcao: { color: 'white' },

  progresso: { marginBottom: 20, fontWeight: '700' },

  cartaoPergunta: { backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 20 },

  imagem: { width: '100%', height: 180, borderRadius: 10, marginBottom: 15 },

  textoPergunta: { fontSize: 18, fontWeight: '700' },

  botaoOpcao: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#e2e8f0'
  },

  textoOpcao: { textAlign: 'center', fontWeight: '600' }
});